from django.apps import AppConfig


class DistrictsappConfig(AppConfig):
    name = 'districtsapp'
